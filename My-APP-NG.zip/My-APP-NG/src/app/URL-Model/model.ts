


const data: any = require('../../assets/book.json');
export class URL{


    
    '/bookData'=data;
}