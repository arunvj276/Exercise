import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BookMouseoverComponent } from './auth/components/mouseover/book-mouseover.component';

const routes: Routes = [{path:'mouseover',component:BookMouseoverComponent}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
