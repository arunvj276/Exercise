import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BookMouseoverComponent } from './components/mouseover/book-mouseover.component';
import { BookComponent } from './components/book/book.component';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { ResetComponent } from './components/reset/reset.component';

const routes: Routes = [{path:'login',component:LoginComponent},
{path:'register',component:RegisterComponent},
{path:'reset',component:ResetComponent},
{path:'book',component:BookComponent},
{path:'mouseover',component:BookMouseoverComponent}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AuthRoutingModule { }
