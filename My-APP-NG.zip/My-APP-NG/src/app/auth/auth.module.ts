import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AuthRoutingModule } from './auth-routing.module';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { ResetComponent } from './components/reset/reset.component';
import {FormsModule} from '@angular/forms';
import { BookComponent, NgbdSortableHeader } from './components/book/book.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgbAlertModule,NgbPaginationModule, NgbModalModule} from '@ng-bootstrap/ng-bootstrap';
import { BookMouseoverComponent } from './components/mouseover/book-mouseover.component';


@NgModule({
  declarations: [LoginComponent, RegisterComponent, ResetComponent,BookComponent,NgbdSortableHeader],
  imports: [
    CommonModule,
    AuthRoutingModule,
    NgbModule,
    NgbAlertModule,
    NgbModalModule,
    NgbPaginationModule,
    FormsModule
  ],
  exports:[LoginComponent, RegisterComponent, ResetComponent,BookComponent]
})
export class AuthModule { }
