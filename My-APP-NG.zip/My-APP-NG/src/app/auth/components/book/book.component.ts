import { Component, Directive, EventEmitter, Input, OnInit, Output, QueryList, ViewChildren } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbModal,NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { BookService, Book } from 'src/app/auth/service/book.service';
import { PagerService } from 'src/app/auth/service/pager.service';



export type SortColumn = keyof Book | '';
export type SortDirection = 'asc' | 'desc' | '';
const rotate: {[key: string]: SortDirection} = { 'asc': 'desc', 'desc': '', '': 'asc' };

const compare = (v1: string | number, v2: string | number) => v1 < v2 ? -1 : v1 > v2 ? 1 : 0;

export interface SortEvent {
  column: SortColumn;
  direction: SortDirection;
}

@Directive({
  selector: 'th[sortable]',
  host: {
    '[class.asc]': 'direction === "asc"',
    '[class.desc]': 'direction === "desc"',
    '(click)': 'rotate()'
  }
})
export class NgbdSortableHeader {

  @Input() sortable: SortColumn = '';
  @Input() direction: SortDirection = '';
  @Output() sort = new EventEmitter<SortEvent>();

  rotate() {
    this.direction = rotate[this.direction];
    this.sort.emit({column: this.sortable, direction: this.direction});
  }
}

@Component({
  selector: 'ngbd-modal-content',
  template: `
  <div class="modal-header bg-primary">
  <h4 class="modal-title text-white">Add Books</h4>
  <button type="button" class="close" aria-label="Close" (click)="activeModal.dismiss('Cross click')">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
<div class="modal-body">
  <p>{{name}}!</p>
</div>
<div class="modal-footer">
  <button type="button" class="btn btn-outline-dark" (click)="activeModal.close('Close click')">Close</button>
</div>
  `
})
export class NgbdModalContent {
  @Input() name: any;

  constructor(public activeModal: NgbActiveModal) {}
}


@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.css']
})

export class BookComponent implements OnInit {



  viewBooks:boolean=false;
  addBooks:boolean=false;
  entries:number=10;

  collectionSize:number=0;

  private allItems: any[]=[];

    // pager object
    pager: any = {};

    // paged items
    pagedItems: any[]=[];

  page = 1;
  pageSize =5;


  books: Book[] = [];
   bookItems:Book[]=[];
   sortBooks:Book[]=[];
    viewMouseOverFLag:boolean=true;

  constructor(private bookService: BookService,private pagerService:PagerService,private router:Router,private modalService: NgbModal) {

    this.refreshpageCount();
   

  }

  ngOnInit() {

    
  }

  getBooks() {

    console.log("view Books called");
    console.log("page-->",this.page);
    console.log("page size ->",this.pageSize);
    console.log(this.bookService.getBooks());
    this.bookItems=this.bookService.getBooks();
    this.collectionSize=this.bookItems.length;
    

  }
  viewBook(){
    this.getBooks();
    this.addBooks=false;
    this.viewBooks=true;
    
  }
  addBook(){
    this.viewBooks=false;
    this.addBooks=true;

  }
  onAddBook(form:NgForm){

    if(this.bookService.addBooks(form)){

      const modalRef = this.modalService.open(NgbdModalContent);
      modalRef.componentInstance.name = 'Book successfully added';
      this.addBook;
      
    }

  }
  selectChangeViewBook(event:any){

    console.log("no of entires - ",event.target.value);
    
    this.entries=event.target.value;
    this.pageSize=this.entries;
   
   


  }
  viewMouseOver(){

    this.bookService.setViewMouseOver();
    this.viewMouseOverFLag=false;
  }
  refreshpageCount() {
    this.getBooks();
    this.books = this.bookItems.slice((this.page - 1) * this.pageSize, (this.page - 1) * this.pageSize + this.pageSize);
    this.sortBooks=this.books;
  }

//   setPage(page: number) {
//     if (page < 1 || page > this.pager.totalPages) {
//         return;
//     }

//     // get pager object from service
//     this.pager = this.pagerService.getPager(this.books.length, page,this.entries);
//     console.log("Pager-->",this.pager);
//     // get current page of items
//     this.pagedItems = this.books.slice(this.pager.startIndex, this.pager.endIndex + 1);
// }


  //   setPage(page: number) {
  //     if (page < 1 || page > this.pager.totalPages) {
  //         return;
  //     }
  //     // get pager object from service
  //     this.pager = this.pagerService.getPager(this.books.length, page,this.entries);
  //     console.log("Pager-->",this.pager);
  //     // get current page of items
  //     this.pagedItems = this.books.slice(this.pager.startIndex, this.pager.endIndex + 1);
  // }

  @ViewChildren(NgbdSortableHeader)
  headers!: QueryList<NgbdSortableHeader>;

onSort({column, direction}: SortEvent) {

  // resetting other headers
  this.headers.forEach(header => {
    if (header.sortable !== column) {
      header.direction = '';
    }
  });
  
  // sorting books
  if (direction === '' || column === '') {
    this.refreshpageCount();
  } else {
    this.books = [...this.sortBooks].sort((a, b) => {
      const res = compare(a[column], b[column]);
      return direction === 'asc' ? res : -res;
    });
  }
}

}
