import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from '../../service/login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  public login=false;
  public login_failure=false;
  private viewBooks:boolean=false;
  private headerView=true;

  constructor(private loginService:LoginService,private router:Router) { }

  ngOnInit(): void {
  }
  onSubmit(form:NgForm){

    if(this.loginService.isAuthentiacted(form.controls['loginUsername'].value,form.controls['loginPassword'].value)){

      this.login=true;
      this.login_failure=false;
      this.headerView=false;
      this.loginService.headerView.next(this.headerView);
      this.router.navigate(['/book']);
    
    }
    else{
      this.login=false;
      this.login_failure=true;
     
      this.loginService.headerView.next(this.headerView);
    }

      

  }
  
  
  viewBook(){
    this.viewBooks=true;
  }

}
