import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BookMouseoverComponent } from './book-mouseover.component';

describe('BookMouseoverComponent', () => {
  let component: BookMouseoverComponent;
  let fixture: ComponentFixture<BookMouseoverComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BookMouseoverComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BookMouseoverComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
