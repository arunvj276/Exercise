import { HostListener } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { Book, BookService } from '../../service/book.service';

@Component({
  selector: 'app-book-mouseover',
  templateUrl: './book-mouseover.component.html',
  styleUrls: ['./book-mouseover.component.css']
})
export class BookMouseoverComponent implements OnInit {

  constructor(private bookService:BookService) { 

    this.refreshpageCount();
    this.viewMouseOver=this.bookService.getViewMouseOver();
    console.log("mouse over view - ",this.viewMouseOver);
  }

  ngOnInit(): void {
  }

  books: Book[] = [];
  bookItems: Book[] = [];
  page = 1;
  pageSize =5;
  viewMouseOver:boolean=false;
  getBooks() {

   
    console.log(this.bookService.getBooks());
    this.bookItems=this.bookService.getBooks();
    
    

  }

  refreshpageCount() {
    this.getBooks();
    this.books = this.bookItems.slice((this.page - 1) * this.pageSize, (this.page - 1) * this.pageSize + this.pageSize);
  }

  @HostListener("window:scroll", [])
  onScroll(): void {
    if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight) {
      // Load Your Data Here
      this.page=((this.books.length)/10)+1;
    }
  }
}
