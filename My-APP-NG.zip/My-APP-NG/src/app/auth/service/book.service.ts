import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import { Observable } from 'rxjs';
import { catchError, map } from "rxjs/operators";
import { NgForm } from '@angular/forms';
import { object } from 'underscore';
//import {URL} from "../.././URL-Model/model";


const data: any ='../../assets/book.json';



export class Book{
  id!: number;
  name!: string;;
  price!: number;
  author!: string;

  constructor(values: Object = {}) {
    Object.assign(this, values);
  }

}



@Injectable({
  providedIn: 'root'
})
export class BookService {


  //bookArr=[{"name": "The Godfather", "price": 10, "author": "Mario Puzo"},{"name": "The Fellowship of the Ring", "price": 15, "author": "J.R.R. Tolkien"},{"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "}];

  bookArr:Book[]=[{"id":0,"name": "The Godfather", "price": 10, "author": "Mario Puzo"},
  {"id":0,"name": "The Fellowship of the Ring", "price": 15, "author": "J.R.R. Tolkien"},
  {"id":0,"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
  {"id":0,"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
  {"id":0,"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
  {"id":0,"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
  {"id":0,"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
  {"id":0,"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
  {"id":0,"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
  {"id":0,"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
  {"id":0,"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
  {"id":0,"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
  {"id":0,"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
  {"id":0,"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
  {"id":0,"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
  {"id":0,"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
  {"id":0,"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
  {"id":0,"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
  {"id":0,"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
  {"id":0,"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
  {"id":0,"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
  {"id":0,"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
  {"id":0,"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
  {"id":0,"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
  {"id":0,"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
  {"id":0,"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
  {"id":0,"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
  {"id":0,"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
  {"id":0,"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
  {"id":0,"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
  {"id":0,"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
  {"id":0,"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
  {"id":0,"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
  {"id":0,"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
  {"id":0,"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
  {"id":0,"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
  {"id":0,"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
  {"id":0,"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "},
  {"id":0,"name": "Harry Potter and the Deathly Hallows", "price": 20, "author": "J.K. Rowling  "}
  ];

  viewMouseOver:boolean=false;

  constructor() {

    for(let i in this.bookArr){

      let idTemp:number=+i;
      this.bookArr[i].id=++idTemp;
    
  }
}

  books:Book[]=[];

  setViewMouseOver():boolean{

    return this.viewMouseOver=true;

  }
  getViewMouseOver():boolean{

    return this.viewMouseOver;
  }
  
  getBooks():Book[]{
      for(let i in this.bookArr){

        let idTemp:number=+i;
        this.bookArr[i].id=++idTemp;
      }
      return this.bookArr;
  }

  addBooks(form:NgForm):boolean{

    const obj=new Book();
    obj.id=(this.bookArr[this.bookArr.length-1].id)+1;
    obj.name=form.controls['bookName'].value;
    obj.author=form.controls['bookAuthor'].value;
    obj.price=form.controls['bookPrice'].value;
    if(this.bookArr.push(obj)){

      console.log("Added book - ",obj);
      console.log("Booka array after added - ",this.bookArr);
      return true;
    }
    
    return false;
  }

  private handleError(error: Response | any){
    console.error('ApiService::Error',error );
    return Observable.throw(error);
  }
}


