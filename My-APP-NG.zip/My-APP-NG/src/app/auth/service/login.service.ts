import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginService {


  public headerView=new Subject<any>();
  
  constructor() { 


  }

  isAuthentiacted(username:any,password:any){

    if(username=="Arun"&&password=="Password"){
      return true;
    }

    return false;
    
  }

}
