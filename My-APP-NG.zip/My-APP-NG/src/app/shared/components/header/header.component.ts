import { Component, OnInit } from '@angular/core';
import { LoginService } from '../../../auth/service/login.service';
import { HomeService } from '../../service/home.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor(private loginService:LoginService,private homeService:HomeService) { }
  public headerFlag:any=false;
  bookFlag=true;
  headerViews:any=true;
  ngOnInit(): void {

    
    this.loginService.headerView.subscribe(data=>{this.headerViews=data});
    console.log("header view - ",this.headerViews);
  }

  loginCarouselView(){

    this.homeService.homeCarouselView.next(true);
    console.log("carosuel flag called");
  }
  

}




