import { Component, OnInit } from '@angular/core';
import { HomeService } from '../../service/home.service';

@Component({
  selector: 'app-home-carousel',
  templateUrl: './home-carousel.component.html',
  styleUrls: ['./home-carousel.component.css']
})
export class HomeCarouselComponent implements OnInit {


    homeCaroselFalg:any=false;
    constructor(private homeService:HomeService){

    }
    ngOnInit():void{

      
      this.homeService.homeCarouselView.subscribe((data: any)=>{this.homeCaroselFalg=data});
      console.log("carousel flag -",this.homeCaroselFalg);
    }
    
    
}
