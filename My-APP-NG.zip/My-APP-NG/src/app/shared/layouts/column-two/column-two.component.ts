import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-column-two',
  templateUrl: './column-two.component.html',
  styleUrls: ['./column-two.component.css']
})
export class ColumnTwoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
