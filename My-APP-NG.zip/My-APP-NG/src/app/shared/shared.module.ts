import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ColumnOneComponent } from './layouts/column-one/column-one.component';
import { HeaderComponent } from './components/header/header.component';
import { RouterModule } from '@angular/router';
import { HomeCarouselComponent } from './components/home-carousel/home-carousel.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ColumnTwoComponent } from './layouts/column-two/column-two.component';
import { BookMouseoverComponent } from '../auth/components/mouseover/book-mouseover.component';
import { FormsModule } from '@angular/forms';



@NgModule({
  declarations: [HeaderComponent, ColumnOneComponent,HomeCarouselComponent,ColumnTwoComponent,BookMouseoverComponent],
  imports: [
    CommonModule,
    RouterModule,
    NgbModule,
    FormsModule
  ],
  exports:[ColumnOneComponent,HomeCarouselComponent,ColumnTwoComponent,BookMouseoverComponent]
})
export class SharedModule { }
