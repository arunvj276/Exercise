import { Component, ViewChild,AfterViewInit } from '@angular/core';
import { CoreService } from '../../service/core.service';
import {Book} from '../../models/Book';
import {MatPaginator} from '@angular/material/paginator';
import {MatTableDataSource} from '@angular/material/table';
import { FormGroup, FormControl, NgForm, FormBuilder } from '@angular/forms';
import { select, Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { BookState } from '../store/reducer/book.reducer';
import { selectBooks, selectBookState } from '../store/selector/book.selectors';
import { addBook, addBooks } from '../store/action/book.actions';
import { MatSidenav } from '@angular/material/sidenav';



@Component({
  selector: 'app-core',
  templateUrl: './core.component.html',
  styleUrls: ['./core.component.css']
})
export class CoreComponent implements AfterViewInit {

  displayedColumns: string[] = ['id', 'name', 'price', 'author'];
  dataSource:any;
  viewBooks:boolean=false;
  viewadd:boolean=false;
  books$!: Observable<Book[]>;
  result?:Book[];
  diaplayBooks:any;
  bookId:number=0;
  formGroup: FormGroup = new FormGroup({
    bookName: new FormControl(''),
    bookPrice: new FormControl(''),
    bookAuthor: new FormControl('')
  });
  
  constructor(private coreService:CoreService,private formBuilder:FormBuilder,private store:Store<BookState>) { 

  
    console.log("core called");
  }
  @ViewChild(MatPaginator) paginator?: MatPaginator;

  ngAfterViewInit(): void {

    setTimeout(() => this.dataSource.paginator = this.paginator);
    
  }
  

  

  addBookView(){
    this.viewadd=true;
    this.viewBooks=false;

  }
  viewBook(){
    console.log("displayed columns - ",this.displayedColumns);
    setTimeout(() => this.dataSource.paginator = this.paginator);
    this.store.pipe(select(selectBooks)).subscribe(data=>this.result=data);
    console.log("Result data - ",this.result);
    this.dataSource = new MatTableDataSource<any>(this.result);
    this.viewadd=false;
    this.viewBooks=true;
  }

  onSubmit(data:any):void{

    const book:any=new Book();
    book.id=++this.bookId;
    book.name=data.bookName;
    book.price=data.bookPrice;
    book.author=data.bookAuthor;
    console.log(" adding book value - ",book);
    this.store.dispatch(addBook(book));
    this.viewadd=false;
    this.viewBooks=false;

  }

 

  

}


