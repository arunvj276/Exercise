import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxSpinnerService } from "ngx-spinner";
import { CoreService } from 'src/app/service/core.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private router:Router,private coreService:CoreService) { }

  viewLogin:boolean=false;
  form: FormGroup = new FormGroup({
    username: new FormControl(''),
    password: new FormControl(''),
  });
  ngOnInit(): void {
  }

  submit() {
    if (this.form.valid) {
      this.submitEM.emit(this.form.value);

      if(this.form.get('username')?.value==='admin'&& this.form.get('password')?.value=='password'){

        this.coreService.headerView.next(true);
        console.log("login successfull");

       
        this.router.navigate(['/core']);

      }
    }
   
  }
  @Input()
  error!: string | null;

  @Output() submitEM = new EventEmitter();

}
