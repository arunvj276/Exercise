import { createAction, props } from '@ngrx/store';
import { Book } from 'src/app/models/Book';


export const ADD_BOOKS = '[Book] Add Books';
export const ADD_BOOKS_SUCCESS = '[Book] Add Books Success';
export const ADD_BOOKS_FAILURE = '[Book] Add Books Failure';


export const addBooks = createAction('[Book] Add Books',(book:Book)=>({book}));


export const addBook = createAction(
    ADD_BOOKS,
    props<{Book: any}>()
  );
  
  export const addBookSuccess = createAction(
    ADD_BOOKS_SUCCESS,
    props<any>()
  );
  
  export const addBookFailure = createAction(
    ADD_BOOKS_FAILURE,
    props<{any: any}>()
);