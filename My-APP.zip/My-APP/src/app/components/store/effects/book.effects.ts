import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { CoreService } from 'src/app/service/core.service';
import { map, exhaustMap, catchError } from 'rxjs/operators';
import * as bookActions from '../action/book.actions';
import { of } from 'rxjs';


@Injectable()
export class BookEffects {



  constructor(private actions$: Actions,private coreService:CoreService) {}


  addBooks$ =createEffect(()=>
          this.actions$.pipe(
            ofType(bookActions.addBook),
            exhaustMap(action=>
              this.coreService.addBooks(action.Book).pipe(
                map(response => bookActions.addBookSuccess(response)),
                catchError((error: any) => of(bookActions.addBookFailure(error)))
              ))));

}


