import { Action, createReducer, on } from '@ngrx/store';
import { Book } from 'src/app/models/Book';
import * as BookActions from '../action/book.actions';


export const bookFeatureKey = 'book';

export interface BookState {

  books: Book[];
  isLoading?: boolean;
  isLoadingSuccess?: boolean;
  isLoadingFailure?: boolean;

}

export const initialState: BookState = {
  books: [],
  isLoading: false,
  isLoadingSuccess: false,
  isLoadingFailure: false
};


export const customeReducer = createReducer(
  initialState,
  on(BookActions.addBooks, 
    (state: BookState, { book }) => ({ ...state, books: [...state.books, book] }))
);
const _= require('lodash');

const bookReducer = createReducer(
  initialState,

  // Get Books
 
  // Create Book Reducers
  on(BookActions.addBooks, (state, {book}) => ({...state, isLoading: true})),
  on(BookActions.addBookSuccess, (state, result) => {
    const books = undefined !== state.books ? _.cloneDeep(state.books) : [];
    const currentTask = undefined !== state.books ? _.cloneDeep(state.books) : {};
    books.push(currentTask);
    return {
      books,
      isLoading: false,
      isLoadingSuccess: true
    };
  }));


export function reducer(state:BookState,action:Action):any{

  //return customeReducer(state,action);
  bookReducer(state,action);
}