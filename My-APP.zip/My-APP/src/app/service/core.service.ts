import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import {Book} from '../models/Book';
import {HttpClient} from '@angular/common/http'



@Injectable({
  providedIn: 'root'
})
export class CoreService {

  public headerView=new Subject<any>();



  constructor(private http:HttpClient) {

  
  this.headerView.next(false);
}


  rootURL = '/api';

  getBooks() {
    return this.http.get(this.rootURL + '/books');
  }

  addBooks(book: any) {
    return this.http.post(this.rootURL + '/addBooks', {book});
  }


}
