import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CoreService } from 'src/app/service/core.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  headers:any=[];
  headerView: boolean=false;
  

  constructor(private coreService:CoreService,private router:Router) {

      this.coreService.headerView.subscribe(data=>this.headerView=data);
      if(this.headerView){
        this.headers.push("Add Book");
        this.headers.push("View Book");

      }

   }

  ngOnInit(): void {
  }

}
